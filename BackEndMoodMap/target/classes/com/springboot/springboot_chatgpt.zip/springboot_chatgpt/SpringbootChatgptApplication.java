package com.springboot.springboot_chatgpt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootChatgptApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootChatgptApplication.class, args);
	}

}
